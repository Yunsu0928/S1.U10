// 동영상 강의에 나온 코드를 그대로 실습하세요
// TODO : DOM으로부터 필요한 엘리먼트를 불러오세요.
console.log('잘 불려왔니?')

let elInputUsername = document.querySelector('#username')
//console.log(elInputUsername);

let elFailureMessage = document.querySelector('.failure-message');
//console.log(elFailureMessage);

let elSuccessMessage = document.querySelector('.success-message');

let elInputPassword = document.querySelector('#password');
let elInputPasswordRe = document.querySelector('#password-retype');
let elMissmessage = document.querySelector('.mismatch-message');

// elFailureMessage.classList.remove('hide')

// elFailureMessage.style.display = 'none' // 보이는건 block, 안보이는건 none

// 아이디 입력창에 글자를 키보드로 입력할 때 >>event 이용 event = ~할 때
// 아이디 입력창 (elInputUsername) // onkeyup : 키보드가 눌렀다 떼어졌을때 하나씩 출력
elInputUsername.onkeyup = function(){
  console.log(elInputUsername.value)              // 아이디 창에 키보드를 눌렀다 떼면 출려됌
  
  if(isMoreThan4Length(elInputUsername.value)){
    //console.log('4글자보다 크네');
    //여기는 성공 메세지가 보여야 한다.
    elSuccessMessage.classList.remove('hide');
    //실패 메서지가 가려져야함
    elFailureMessage.classList.add('hide');

  }else {
    // console.log('짧다...');
    // 여기는 성공 메세지가 가려져야한다.
    elSuccessMessage.classList.add('hide');
    // 실패 메세지가 보여야 함
    elFailureMessage.classList.remove('hide');
  }
}

elInputPasswordRe.onkeyup = function(){
  console.log(elInputPassword.password1);

  if (isMatch(elInputPassword.value, elInputPasswordRe.value)){
    elMissmessage.classList.add('hide')
  }else elMissmessage.classList.remove('hide')
}






// 글자 수가 4개 이상이면, 사용할 수 있는 아이디입니다 메세지가 출력된다.

function isMoreThan4Length(value) {
  // TODO : 동영상 강의를 보고 이 함수를 완성하세요.
  return value.length >= 4;           // 입력한 글자가 4글자 이상이면 true
}

function isMatch (password1, password2) {
  // TODO : 동영상 강의를 보고 이 함수를 완성하세요.
  return (password1===password2) ? true : false
}




// 비밀번호 >> 비밀번호 확인과 같으면 두 값이 일치합니다
// 전화번호 추가해도 된다 : 숫자가 아니면 fail
// 회원가입 : 나머지 3칸에 입력을 하지 않으면 작동안함
